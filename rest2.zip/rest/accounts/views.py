from django.shortcuts import render
from django.shortcuts import HttpResponse 
# Create your views here.

def registerUser(request):
    return HttpResponse('This is a user ')
